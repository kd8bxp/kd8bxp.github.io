/* key.c
 * you can build this like: 
 * gcc -Wall key.c -o key -lwiringPi
 * sudo ./key
*/
#include <stdio.h>
#include <string.h> 
#include <errno.h>

#include<wiringPi.h>


char KEY[]={4,9,15,16,21,22,23,24,25,26,27,28,29};
unsigned char i;

int main(){
	if (wiringPiSetup() < 0)return 1 ;
	for(i=0;i<13;i++)
	{
		pinMode (KEY[i],INPUT) ;//pinMode (LED, OUTPUT) ;
		pullUpDnControl(KEY[i], PUD_UP);
	}

	while(1)
	{
			if (digitalRead (KEY[0]) == 0)  
    			{
				printf ("tl \n") ;
    			delay(500);
			}
			else if (digitalRead (KEY[1]) == 0)
                        {
                                printf ("press \n") ;
                        delay(500);
                        }
                        else if (digitalRead (KEY[2]) == 0)
                        {
                                printf ("tr \n") ;
                        delay(500);
                        }
                        else if (digitalRead (KEY[3]) == 0)
                        {
                                printf ("x \n") ;
                        delay(500);
                        }
                        else if (digitalRead (KEY[4]) == 0)
                        {
                                printf ("up \n") ;
                        delay(500);
                        }
                        else if (digitalRead (KEY[5]) == 0)
                        {
                                printf ("right \n") ;
                        delay(500);
                        }
                        else if (digitalRead (KEY[6]) == 0)
                        {
                                printf ("left \n") ;
                        delay(500);
                        }
                        else if (digitalRead (KEY[7]) == 0)
                        {
                                printf ("start \n") ;
                        delay(500);
                        }
                        else if (digitalRead (KEY[8]) == 0)
                        {
                                printf ("select \n") ;
                        delay(500);
                        }
                        else if (digitalRead (KEY[9]) == 0)
                        {
                                printf ("y \n") ;
                        delay(500);
                        }
                        else if (digitalRead (KEY[10]) == 0)
                        {
                                printf ("down \n") ;
                        delay(500);
                        }
                        else if (digitalRead (KEY[11]) == 0)
                        {
                                printf ("b \n") ;
                        delay(500);
                        }
                        else if (digitalRead (KEY[12]) == 0)
                        {
                                printf ("a \n") ;
                        delay(500);
                        }
	}
}
